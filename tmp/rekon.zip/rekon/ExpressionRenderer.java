/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 University of Manchester
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package uk.ac.manchester.cs.rekon;

/**
 * @author Colin Puleston
 */
class ExpressionRenderer {

	static private final String TAB = "  ";

	private StringBuilder rendering;
	private String tabs;

	ExpressionRenderer() {

		this(new StringBuilder(), "");

		addLine("Expression:");

		tabs += TAB;
	}

	ExpressionRenderer nextLevel() {

		return new ExpressionRenderer(rendering, tabs + TAB);
	}

	void addLine(Object obj) {

		rendering.append(tabs + obj + '\n');
	}

	String getRendering() {

		return rendering.toString();
	}

	private ExpressionRenderer(StringBuilder rendering, String tabs) {

		this.rendering = rendering;
		this.tabs = tabs;
	}
}
