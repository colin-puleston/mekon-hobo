/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 University of Manchester
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package uk.ac.manchester.cs.rekon;

import java.util.*;

import org.semanticweb.owlapi.model.*;

/**
 * @author Colin Puleston
 */
class Classifier {

	private Names names;
	private DescriptionExtractor extractor;

	private ClassDefinition rootClassDefinition = new ClassDefinition();
	private SortedSet<ClassDefinition> classDefinitions = new TreeSet<ClassDefinition>();

	private Set<Description> classDescriptions = new HashSet<Description>();

	private class Initialiser {

		private Assertions assertions;

		private Map<Name, Description> classDescFinder = new HashMap<Name, Description>();
		private Set<Name> classDefReferencedNames = new HashSet<Name>();

		Initialiser(Assertions assertions) {

			this.assertions = assertions;

			extractClassDefinitionsAndDescriptions();

			resolveClassDescriptionSuccessors();
			setClassDefinitionActiveAncestors();

			assembleClassDefinitionHierarchy();
		}

		private void extractClassDefinitionsAndDescriptions() {

			for (ClassName name : names.getForAllClasses()) {

				OWLClass cls = name.getCls();

				extractAssertedClassDefinitions(name, cls);
				checkExtractAssertedClassDescription(cls);
			}
		}

		private void resolveClassDescriptionSuccessors() {

			Set<Description> done = new HashSet<Description>();

			for (Description d : classDescriptions) {

				resolveClassDescriptionSuccessors(d, done);
			}
		}

		private void setClassDefinitionActiveAncestors() {

			for (ClassDefinition d : classDefinitions) {

				d.getDefinition().setActiveAncestors(classDefReferencedNames);
			}
		}

		private void assembleClassDefinitionHierarchy() {

			for (ClassDefinition d : classDefinitions) {

				rootClassDefinition.absorb(d);
			}
		}

		private void extractAssertedClassDefinitions(ClassName name, OWLClass cls) {

			for (Description d : extractAssertedDefinitions(cls)) {

				classDefinitions.add(new ClassDefinition(name, d));
				classDefReferencedNames.addAll(d.getReferencedNames().getSet());
			}
		}

		private void checkExtractAssertedClassDescription(OWLClass cls) {

			Description d = extractAssertedDescription(cls);

			if (d != null) {

				classDescriptions.add(d);
				classDescFinder.put(d.getName(), d);
			}
		}

		private Set<Description> extractAssertedDefinitions(OWLClass cls) {

			Collection<OWLClassExpression> equs = assertions.getDistictEquivalents(cls);

			return extractor.extractStructuredDescriptions(equs);
		}

		private Description extractAssertedDescription(OWLClass cls) {

			Collection<OWLClassExpression> sups = assertions.getSupers(cls);
			Set<Description> descs = extractor.extractStructuredDescriptions(sups);

			return descs.isEmpty() ? null : new Description(names.get(cls), descs);
		}

		private Set<Expression> resolveClassDescriptionSuccessors(
									Description desc,
									Set<Description> done) {

			if (done.add(desc)) {

				for (Name an : desc.getName().getAncestors()) {

					Description ad = classDescFinder.get(an);

					desc.addSuccessors(resolveClassDescriptionSuccessors(ad, done));
				}
			}

			return desc.getSuccessors();
		}
	}

	Classifier(Assertions assertions, Names names) {

		this.names = names;

		extractor = new DescriptionExtractor(names);

		new Initialiser(assertions);

		classify();
	}

	Set<ClassName> getEquivalents(OWLClassExpression expr) {

		Description d = extractor.extractStructuredDescription(expr);

		if (d != null) {

			return rootClassDefinition.getEquivalents(d);
		}

		return Collections.emptySet();
	}

	Set<ClassName> getSupers(OWLClassExpression expr, boolean directOnly) {

		Description d = extractor.extractStructuredDescription(expr);

		if (d != null) {

			return rootClassDefinition.getSupers(d, directOnly);
		}

		return Collections.emptySet();
	}

	private void classify() {

		for (ClassDefinition d : classDefinitions) {

			d.inferSubsumptionsFromClassDefinition();
		}

		for (Description d : classDescriptions) {

			rootClassDefinition.inferAllSubsumptionsForClassDescription(d);
		}

		names.resolveAllLinksPostClassification();
		extractor.setCacheAdditionsEnabled(false);

		resetClassDescriptionNameReferences();
		resetClassDefinitionNameReferences();
	}

	private void resetClassDescriptionNameReferences() {

		for (Description d : classDescriptions) {

			d.resetNameReferences();
		}
	}

	private void resetClassDefinitionNameReferences() {

		for (ClassDefinition d : classDefinitions) {

			d.getDefinition().resetNameReferences();
		}
	}
}
